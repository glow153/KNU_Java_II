package week03.problem03;

public class Main {
	public static void main(String[] args) {
//		Lottery lotto = new Lottery();
//		lotto.playLottery();
		
		LotteryEx lotto = new LotteryEx();
		lotto.playLottery(true);
	}
}
