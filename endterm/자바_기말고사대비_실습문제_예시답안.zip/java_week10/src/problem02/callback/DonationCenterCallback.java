package problem02.callback;

public interface DonationCenterCallback {
	public void onRefresh(String s);
	public void noMoney();
}
