package problem02.callback;

public interface OnDonateListener {
	public void onDonate(int amount);
}
