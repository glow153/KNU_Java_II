package problem02.callback;

public interface OnReceiveListener {
	public void onReceive(int amount);
}
