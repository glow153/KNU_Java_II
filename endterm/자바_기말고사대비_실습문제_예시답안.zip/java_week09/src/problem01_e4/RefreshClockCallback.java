package problem01_e4;

public interface RefreshClockCallback {
	void execute(String s);
}
