package problem02;

public interface OnWaterDrainedListener {
	public void onWaterDrained(String s);
}
