package problem02;

public interface OnWaterPouredListener {
	public void onWaterPoured(String s);
}
