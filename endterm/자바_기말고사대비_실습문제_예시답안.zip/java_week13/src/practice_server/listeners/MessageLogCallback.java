package practice_server.listeners;

public interface MessageLogCallback {
	public void writeMsg(String msg);
}
