package practice_server.listeners;

public interface OnCalculationReceived {
	public void onReceived(String formula);
}
