package practice_server.listeners;

public interface OnClientDisconnectedListener {
	public void onDisconnected(int id, String name);
}
