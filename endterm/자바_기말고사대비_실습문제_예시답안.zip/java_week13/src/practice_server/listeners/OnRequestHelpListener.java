package practice_server.listeners;

public interface OnRequestHelpListener {
	public void sendHelp(int id);
}
