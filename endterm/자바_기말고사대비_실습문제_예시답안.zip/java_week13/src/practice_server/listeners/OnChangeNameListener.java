package practice_server.listeners;

public interface OnChangeNameListener {
	public void changeName(int id, String oldName, String newName);
}
