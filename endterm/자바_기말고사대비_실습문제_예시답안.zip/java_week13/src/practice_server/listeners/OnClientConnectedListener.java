package practice_server.listeners;

public interface OnClientConnectedListener {
	public void onConnected(int id, String name);
}
