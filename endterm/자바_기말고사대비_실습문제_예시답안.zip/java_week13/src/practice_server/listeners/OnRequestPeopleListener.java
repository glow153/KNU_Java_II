package practice_server.listeners;

public interface OnRequestPeopleListener {
	public void sendPeople(int id);
}
