package practice_server.listeners;

public interface OnCalculationReceivedListener {
	public void onReceived(String formula);
}
