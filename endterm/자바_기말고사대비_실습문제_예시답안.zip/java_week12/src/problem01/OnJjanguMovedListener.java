package problem01;

public interface OnJjanguMovedListener {
	public void onMoved();
}
